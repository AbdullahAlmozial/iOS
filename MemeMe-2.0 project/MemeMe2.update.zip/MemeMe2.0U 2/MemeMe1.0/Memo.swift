//
//  Memo.swift
//  MemeMe1.0
//
//  Created by عبدالله محمد on 11/24/18.
//  Copyright © 2018 udacity. All rights reserved.
//

import Foundation
