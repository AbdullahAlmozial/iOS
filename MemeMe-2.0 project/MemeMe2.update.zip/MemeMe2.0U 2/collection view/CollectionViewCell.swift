//
//  CollectionViewCell.swift
//  MemeMe1.0
//
//  Created by عبدالله محمد on 12/16/18.
//  Copyright © 2018 udacity. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageview: UIImageView!
}
