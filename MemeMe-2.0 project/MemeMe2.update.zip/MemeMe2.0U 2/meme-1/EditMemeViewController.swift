//
//  ViewController.swift
//  MemeMe1.0
//
//  Created by عبدالله محمد on 11/23/18.
//  Copyright © 2018 udacity. All rights reserved.
//

import UIKit

class EditMemeViewController: UIViewController ,UIImagePickerControllerDelegate , UINavigationControllerDelegate , UITextFieldDelegate {
    
    @IBOutlet weak var topText: UITextField!
    @IBOutlet weak var bottomText: UITextField!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var shareButton: UIBarButtonItem!
    @IBOutlet weak var albumButton: UIBarButtonItem!
    @IBOutlet weak var cameraButton: UIBarButtonItem!
    @IBOutlet weak var cancelButton: UIBarButtonItem!
    @IBOutlet weak var navigation: UINavigationBar!
    @IBOutlet weak var toolbar: UIToolbar!
    var imagePicker  = UIImagePickerController()
    
    let memeTextAttributes:[NSAttributedString.Key: Any] = [
        NSAttributedString.Key.strokeColor: UIColor.black,
        NSAttributedString.Key.foregroundColor: UIColor.white,
        NSAttributedString.Key.font: UIFont(name: "HelveticaNeue-CondensedBlack", size: 40)!,
        NSAttributedString.Key.strokeWidth: -3.6]
    override func viewDidLoad() {
        super.viewDidLoad()
        topText.delegate = self
        bottomText.delegate = self
        prepareTextField(textField: topText, defaultText:"TOP")
        prepareTextField(textField: bottomText, defaultText:"BOTTOM")
        cameraButton.isEnabled = UIImagePickerController.isSourceTypeAvailable(.camera)
     
    }
    func prepareTextField(textField: UITextField, defaultText: String) { }
    
    func prerper(textfiled:UITextField)  {
        textfiled.defaultTextAttributes = memeTextAttributes
        textfiled.textAlignment  = .center
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    func pickImage(sourceType: UIImagePickerController.SourceType){
        
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.sourceType = sourceType
        self.present(imagePicker, animated: true, completion:nil)
    }
  
    @IBAction func AlbumAction(_ sender: AnyObject) {
        pickImage(sourceType: UIImagePickerController.SourceType.photoLibrary)


    }
    @IBAction func CameraAction(_ sender: Any) {
     
        pickImage(sourceType: UIImagePickerController.SourceType.camera)

    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage
        {
            imageView.image = image
        }
        dismiss(animated: true, completion: nil)

        }
    override func viewWillAppear(_ animated: Bool) {
      
        shareButton.isEnabled = imageView.image != nil
       prerper(textfiled: bottomText)
        prerper(textfiled: topText)
        subscribeToshowKeyboardNotifications()
        subscribeToHideKeyboardNotifications()
 
        
    }
    override func viewWillDisappear(_ animated: Bool) {
        
        super.viewWillDisappear(animated)
        unsubscribeToKeyboardNotifications()
    }
    
    func subscribeToshowKeyboardNotifications(){
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: UIResponder.keyboardDidShowNotification, object: nil)
    }
    
    func subscribeToHideKeyboardNotifications(){
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: UIResponder.keyboardDidHideNotification, object: nil)
    }
    
    
    func unsubscribeToKeyboardNotifications(){
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    @objc func keyboardWillShow(_ notification:Notification){
        
        if bottomText.isEditing {
            view.frame.origin.y = -getKeyboardHeight(notification)
        }
    }
    
    
    @objc func keyboardWillHide(_ notification:Notification){
        view.frame.origin.y = 0
        
    }
    
    func getKeyboardHeight(_ notification:Notification) -> CGFloat {
        let userInfo = notification.userInfo
        let keyboardSize = userInfo![UIResponder.keyboardFrameEndUserInfoKey] as! NSValue
        return keyboardSize.cgRectValue.height
    }
    
    @IBAction func cancelAction(_ sender: Any) {
    
        
       self.dismiss(animated: true, completion: nil)
     /*   topText.text = "TOP"
        bottomText.text = "BOTTOM"
        imageView.image = nil
        shareButton.isEnabled = false*/
        
        
    }
    func generateMemedImage() -> UIImage {

     hideToolbars(true)
        UIGraphicsBeginImageContext(view.frame.size)
        view.drawHierarchy(in: view.frame, afterScreenUpdates: true)
        let memedImage: UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        
        hideToolbars(false)
        
        return memedImage
    }
    
    func save() {
        let meme = Meme(topText: topText.text!, bottomText: bottomText.text!, originalImage: imageView.image!, memedImage: generateMemedImage())
        let object = UIApplication.shared.delegate
        let appDelegate = object as! AppDelegate
        appDelegate.memes.append(meme)
    }
    @IBAction func SharedImageAction(_ sender: Any) {
        let memedImage = generateMemedImage()
        let activityView = UIActivityViewController(activityItems: [memedImage], applicationActivities: nil)
        
        activityView.completionWithItemsHandler = {(activity, completed, items, error) in
            if (completed) {
                let _ = self.save()
                self.dismiss(animated: true, completion: nil)
            }
        }
        
        self.present(activityView, animated: true, completion: nil)
        
    }
    func hideToolbars(_ hide: Bool) {
        if hide == true {
            navigation.isHidden = true
            toolbar.isHidden = true
            
        }
        else {
            navigation.isHidden = false
            toolbar.isHidden = false
            
        }
    }

    
}

