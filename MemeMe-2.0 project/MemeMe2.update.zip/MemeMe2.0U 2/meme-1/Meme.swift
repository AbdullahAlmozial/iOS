//
//  Meme.swift
//  MemeMe1.0
//
//  Created by عبدالله محمد on 11/24/18.
//  Copyright © 2018 udacity. All rights reserved.
//


import UIKit

struct Meme {//structure of meme to save its info
    var topText: String
    var bottomText: String
    var originalImage: UIImage
    var memedImage: UIImage
}
