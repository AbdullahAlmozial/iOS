//
//  SentMemesDetailViewController.swift
//  MemeMe1.0
//
//  Created by عبدالله محمد on 12/16/18.
//  Copyright © 2018 udacity. All rights reserved.
//

import UIKit

class SentMemesDetailViewController: UIViewController {
    var imagememe = UIImage()

    @IBOutlet weak var imageview: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        imageview.image = imagememe
    }
}
