//
//  Tableview.swift
//  MemeMe1.0
//
//  Created by عبدالله محمد on 12/15/18.
//  Copyright © 2018 udacity. All rights reserved.
//

import UIKit
import Foundation

class SentMemesTableViewController: UIViewController  {
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
  
    @IBOutlet weak var tableview: UITableView!
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    override func viewDidAppear(_ animated: Bool) {
        tableview.reloadData()
        
    }
}
extension SentMemesTableViewController : UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return appDelegate.memes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:TableViewCell = tableView.dequeueReusableCell(withIdentifier:"tablecell" , for: indexPath) as! TableViewCell
        
         let meme = appDelegate.memes[indexPath.row]
        
        cell.top.text = meme.topText
        cell.buttom.text = meme.bottomText
        cell.iamgeview.image = meme.originalImage
        
        
        return  cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let detailVC = storyboard?.instantiateViewController(withIdentifier: "SentMemesDetailViewController") as! SentMemesDetailViewController
        
        let Display = appDelegate.memes[indexPath.row]
        detailVC.imagememe = Display.memedImage
        self.navigationController?.pushViewController(detailVC, animated: true)
    }
    
    
    
}
extension SentMemesTableViewController : UITableViewDelegate{}
