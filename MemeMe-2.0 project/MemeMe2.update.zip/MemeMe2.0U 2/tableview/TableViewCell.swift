//
//  TableViewCell.swift
//  MemeMe1.0
//
//  Created by عبدالله محمد on 12/15/18.
//  Copyright © 2018 udacity. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet weak var iamgeview: UIImageView!
    @IBOutlet weak var top: UILabel!
    @IBOutlet weak var buttom: UILabel!
    

}
