//
//  TableViewCell.swift
//  onTheMapV1
//
//  Created by عبدالله محمد on 1/21/19.
//  Copyright © 2019 udacity. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell  {

    @IBOutlet weak var imageview: UIImageView!
    @IBOutlet weak var firstname: UILabel!
    @IBOutlet weak var lastname: UILabel!
    @IBOutlet weak var urllinke: UILabel!
    
var Imagee: UIImage = UIImage(named:"icon_pin")!
    
    func setdata(StudentData: StudentLocation) {
        if let frist = StudentData.firstName , let last = StudentData.lastName , let url = StudentData.mediaURL {
            
            firstname.text = "\(frist)"
            lastname.text = "\(last)"
            urllinke.text = "\(url)"
            imageview.image = Imagee
            
        }
    }
}
