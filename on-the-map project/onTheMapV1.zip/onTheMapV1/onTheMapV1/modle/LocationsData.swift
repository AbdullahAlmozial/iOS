//
//  File.swift
//  onTheMapV1
//
//  Created by عبدالله محمد on 1/15/19.
//  Copyright © 2019 udacity. All rights reserved.
//

import Foundation

struct LocationsData {
    var studentLocations: [StudentLocation] = []
}

