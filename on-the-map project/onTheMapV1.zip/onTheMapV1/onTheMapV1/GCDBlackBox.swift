//
//  File.swift
//  onTheMapV1
//
//  Created by عبدالله محمد on 1/16/19.
//  Copyright © 2019 udacity. All rights reserved.
//

import Foundation

func UIUpdatesOnMain(_ updates: @escaping () -> Void) {
    DispatchQueue.main.async {
        updates()
    }
}
