//
//  ww.swift
//  onTheMapV1
//
//  Created by عبدالله محمد on 1/15/19.
//  Copyright © 2019 udacity. All rights reserved.
//

import Foundation

struct fixedAPI {
    
    struct HeaderKeys {
        static let PARSE_APP_ID = "X-Parse-Application-Id"
        static let PARSE_API_KEY = "X-Parse-REST-API-Key"
        static let Accept = "Accept"
        static let ContentType  = "Content-Type"
        
    }
    struct HeaderValues {
        static let PARSE_APP_ID = "QrX47CA9cyuGewLdsL7o5Eb8iug6Em8ye0dnAbIr"
        static let PARSE_API_KEY = "QuWThTdiRmTux3YaDseUSEpUKo7aBYM737yKd4gY"
        static let json = "application/json"
    }
    struct ParameterKeys {
        static let LIMIT = "limit"
        static let SKIP = "skip"
        static let ORDER = "order"
    }
}

enum HTTPMethod: String {
    case post = "POST"
    case get = "GET"
    case put = "PUT"
    case delete = "DELETE"
}
struct udacityAPI{
        private static var userInfo = infoOfStudents()
    
    static let SESSION = "https://onthemap-api.udacity.com/v1/session"
    static let PUBLIC_USER = "https://onthemap-api.udacity.com/v1/users/"
    static let userFirstNameAndLastName = "https://onthemap-api.udacity.com/v1/users/\(userInfo.key)"
    static let deleteSession = "https://onthemap-api.udacity.com/v1/session"
    static let signuplink = "https://www.udacity.com/account/auth#!/signup"
    
}


struct parseAPI{
    private static let MAIN = "https://parse.udacity.com"
    static let STUDENT_LOCATION = MAIN + "/parse/classes/StudentLocation"

}
enum parameter: String {
    case createdAt
    case firstName
    case lastName
    case latitude
    case longitude
    case mapString
    case mediaURL
    case objectId
    case uniqueKey
    case updatedAt
}








