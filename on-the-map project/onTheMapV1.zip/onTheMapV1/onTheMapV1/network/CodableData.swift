//
//  udacityData.swift
//  onTheMapV1
//
//  Created by عبدالله محمد on 1/17/19.
//  Copyright © 2019 udacity. All rights reserved.
//
import Foundation
import UIKit

struct postingSession: Codable {
    var account:accountcontent
    var session:sessioncontent
    
}

struct accountcontent: Codable {
    var registered:Bool?
    var key:String?
}
struct sessioncontent: Codable {
    var id:String?
    var expiration:String?
}
struct getStudentLocationss: Codable {
    var results:[StudentLocation]?
    }
struct StudentLocation: Codable {
    var createdAt: String?
    var firstName: String?
    var lastName: String?
    var latitude: Double?
    var longitude: Double?
    var mapString: String?
    var mediaURL: String?
    var objectId: String?
    var uniqueKey: String?
    var updatedAt: String?
    
}
extension StudentLocation {
    init(mapString: String, mediaURL: String ) {
        self.mapString = mapString
        self.mediaURL = mediaURL
    }
}
struct getUserInfoo: Codable {
    var last_name: String?
     var first_name: String?
    
}












