//
//  parseApi.swift
//  onTheMapV1
//
//  Created by عبدالله محمد on 1/20/19.
//  Copyright © 2019 udacity. All rights reserved.
//

import Foundation

struct parseAPI{
    
    
private static let MAIN = "https://parse.udacity.com"
static let STUDENT_LOCATION = MAIN + "/parse/classes/StudentLocation"
    
}
