//
//  udacityApi.swift
//  onTheMapV1
//
//  Created by عبدالله محمد on 1/20/19.
//  Copyright © 2019 udacity. All rights reserved.
//

import Foundation

struct udacityAPI{
    
static let SESSION = "https://onthemap-api.udacity.com/v1/session"
static let PUBLIC_USER = "https://onthemap-api.udacity.com/v1/users/"
static let userFirstNameAndLastName = "https://onthemap-api.udacity.com/v1/users/< user_id >"
static let deleteSession = "https://onthemap-api.udacity.com/v1/session"
    
}


