//
//  a.swift
//  onTheMapV1
//
//  Created by عبدالله محمد on 1/15/19.
//  Copyright © 2019 udacity. All rights reserved.
//

import Foundation

struct infoOfStudents {
    var key: String?
    var firstName: String?
    var lastName: String?
    
}



