//
//  api.swift
//  onTheMapV1
//
//  Created by عبدالله محمد on 1/15/19.
//  Copyright © 2019 udacity. All rights reserved.
//

import Foundation
import UIKit

class udacityAPIMethods {
    public static var infoOfStudent = infoOfStudents()
    private static var sessionId: String?

    
    static func signupurl() {
        if let url = URL(string: udacityAPI.signuplink),
            UIApplication.shared.canOpenURL(url) {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        }
        
    }
    static func postSession(username: String, password: String, completion: @escaping (String?)->Void) {
        guard let url = URL(string: udacityAPI.SESSION ) else {
            completion("problem with postSession url ")
            return
        }
        var request = URLRequest(url: url)
        request.httpMethod = HTTPMethod.post.rawValue
        request.addValue(fixedAPI.HeaderValues.json, forHTTPHeaderField: fixedAPI.HeaderKeys.Accept)
        request.addValue(fixedAPI.HeaderValues.json, forHTTPHeaderField: fixedAPI.HeaderKeys.ContentType)
        
        request.httpBody = "{\"udacity\": {\"username\": \"\(username)\", \"password\": \"\(password)\"}}".data(using: .utf8)
        let session = URLSession.shared
        let task = session.dataTask(with: request) { data, response, error in
            var err: String?
            if let statusCode = (response as? HTTPURLResponse)?.statusCode {
                if statusCode >= 200 && statusCode < 300 {
                    let range = Range(5..<data!.count)
                    let newData = data?.subdata(in: range)
             do {
                 let decoder = JSONDecoder()
                    let postSession = try decoder.decode(postingSession.self, from: newData!)
                    let sessionDict = postSession.session
                    let accountDict = postSession.account
                    self.infoOfStudent.key = accountDict.key
                    self.sessionId = sessionDict.id
                self.getuserinfo(completion: { err in})
             }
             catch  {
                completion("problem with codeable")
                        }
                } else {
                    err = "Check the entered data"
                }
            } else {
                err = "Connect to Internet"
            }
                completion(err)
        }
        task.resume()
    }
static func deldteSeesion( completion: @escaping (String?)->Void) {
    guard let url = URL(string: udacityAPI.deleteSession ) else {
        completion("problem with deldteSeesion url")
        return
    }
    var request = URLRequest(url: url)
    request.httpMethod = HTTPMethod.delete.rawValue
    var xsrfCookie: HTTPCookie? = nil
    let sharedCookieStorage = HTTPCookieStorage.shared
    for cookie in sharedCookieStorage.cookies! {
    if cookie.name == "XSRF-TOKEN" {
        xsrfCookie = cookie }
    }
    if let xsrfCookie = xsrfCookie {
        request.setValue(xsrfCookie.value, forHTTPHeaderField: "X-XSRF-TOKEN")
    }
    let session = URLSession.shared
    let task = session.dataTask(with: request) { data, response, error in
        
        var err: String?
        if let statusCode = (response as? HTTPURLResponse)?.statusCode {
            if statusCode >= 200 && statusCode < 300 {
                let range = Range(5..<data!.count)
                let newData = data?.subdata(in: range)
                 print(String(data: newData!, encoding: .utf8)!)
    
            } else {
                          err = "Check the entered data"
            }
        } else {
           err = "Connect to Internet"
        }
            completion(err)
    }
    task.resume()
    }
    
 static func getuserinfo( completion: @escaping (String?)->Void) {
    guard let url = URL(string:udacityAPI.userFirstNameAndLastName) else {
                completion("problem with getuserinfo url")
        return
    }
    var request = URLRequest(url: url)
    request.httpMethod = HTTPMethod.get.rawValue
    let session = URLSession.shared
    let task = session.dataTask(with: request) { data, response, error in
        var err: String?
        if let statusCode = (response as? HTTPURLResponse)?.statusCode {
            if statusCode >= 200 && statusCode < 300 {
                let range = Range(5..<data!.count)
                let newData = data?.subdata(in: range)
                do {
                    let decoder = JSONDecoder()
                    let getUserInfo = try decoder.decode(getUserInfoo.self, from: newData!)
                    self.infoOfStudent.firstName = getUserInfo.first_name
                       self.infoOfStudent.lastName = getUserInfo.last_name
                    
        

                }
                catch {
                     completion("problem with codeable")
                }
            } else {
                   err = "Check the entered data"
            }
        } else {
            err = "Connect to Internet"
        }
        DispatchQueue.main.async {
              completion(err)
        }
    }
    task.resume()
    }
    
    
    class ParserAPIMethods {

        static func getStudentLocations(limit: Int = 100, skip: Int = 400, orderBy: parameter = .updatedAt, completion: @escaping (LocationsData?)->Void) {
            guard let url = URL(string: "\(parseAPI.STUDENT_LOCATION)?\(fixedAPI.ParameterKeys.LIMIT)=\(limit)&\(fixedAPI.ParameterKeys.SKIP)=\(skip)&\(fixedAPI.ParameterKeys.ORDER)=-\(orderBy.rawValue)") else {
                completion(nil)
                return
            }
            var request = URLRequest(url: url)
            request.httpMethod = HTTPMethod.get.rawValue
            request.addValue(fixedAPI.HeaderValues.PARSE_APP_ID, forHTTPHeaderField: fixedAPI.HeaderKeys.PARSE_APP_ID)
            request.addValue(fixedAPI.HeaderValues.PARSE_API_KEY, forHTTPHeaderField: fixedAPI.HeaderKeys.PARSE_API_KEY)
            let session = URLSession.shared
            let task = session.dataTask(with: request) { data, response, error in
                var studentLocations: [StudentLocation] = []
                if let statusCode = (response as? HTTPURLResponse)?.statusCode {
                    if statusCode < 400 {
                        
                        var resultt: [StudentLocation] = []
                        do {
                            let decoder = JSONDecoder()
                            
                            let getStudentLocations = try decoder.decode(getStudentLocationss.self, from: data!)
                            resultt = getStudentLocations.results!
                        }
                        catch let error {
                            print(error)
                        }
                        
                        completion(LocationsData(studentLocations: resultt))
                    }
                }
            }
            task.resume()
        }
        
        static func postLocation(_ StudentLocations: StudentLocation, completion: @escaping (String?)->Void) {
            
            var request = URLRequest(url: URL(string: parseAPI.STUDENT_LOCATION)!)
            request.httpMethod = HTTPMethod.post.rawValue
            request.addValue(fixedAPI.HeaderValues.PARSE_APP_ID, forHTTPHeaderField: fixedAPI.HeaderKeys.PARSE_APP_ID)
            request.addValue(fixedAPI.HeaderValues.PARSE_API_KEY, forHTTPHeaderField: fixedAPI.HeaderKeys.PARSE_API_KEY)
            request.addValue(fixedAPI.HeaderValues.json, forHTTPHeaderField: fixedAPI.HeaderKeys.ContentType)
            request.httpBody = "{\"uniqueKey\": \"\(infoOfStudent.key ?? "no key")\", \"firstName\":\"\(infoOfStudent.firstName ?? "john")\", \"lastName\": \"\(infoOfStudent.lastName ?? "Doe")\",\"mapString\":\"\(StudentLocations.mapString ?? "no mapString")\", \"mediaURL\": \"\(StudentLocations.mediaURL ?? "no mediumURl")\",\"latitude\":\(StudentLocations.latitude ?? 0), \"longitude\":\(StudentLocations.longitude ?? 0)}".data(using: .utf8)
            let session = URLSession.shared
            let task = session.dataTask(with: request) { data, response, error in
                
                var err: String?
                if let statusCode = (response as? HTTPURLResponse)?.statusCode {
                    if statusCode >= 200 && statusCode < 300 {
                        let range = Range(5..<data!.count)
                        let newData = data?.subdata(in: range)
                        print(String(data: newData!, encoding: .utf8)!)
                        print(infoOfStudent.firstName)
                        print(infoOfStudent.lastName)
                        print ("post")
                        
                    } else {
                        err = "Check the entered data"
                    }
                } else {
                    err = "Connect to Internet"
                }
                completion(err)
            }
            task.resume()
        }
    }

}


