//
//  File.swift
//  onTheMapV1
//
//  Created by عبدالله محمد on 1/15/19.
//  Copyright © 2019 udacity. All rights reserved.
//

import Foundation

extension String {
    var toDate: Date? {
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        return formatter.date(from: self)
    }
}
