//
//  sendLocationstorybord.swift
//  onTheMapV1
//
//  Created by عبدالله محمد on 1/15/19.
//  Copyright © 2019 udacity. All rights reserved.
//

import UIKit
import MapKit

class sendLocationstorybord: UIViewController , MKMapViewDelegate {
    
  
    
private static var userInfoo = infoOfStudents()
    
    
    @IBOutlet weak var mapview: MKMapView!
      var location: StudentLocation?
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupMap()
    }
    @IBAction func finshAction(_ sender: Any) {

        udacityAPIMethods.ParserAPIMethods.postLocation(self.location!){(errorString) in
        UIUpdatesOnMain { //for DispatchQueue.main.async as TheMovieManager project
                guard errorString == nil else {
                    self.showAlertError(errorString) // if any error as TheMovieManager
                    return
                }
  self.dismiss(animated: true, completion: nil)
            } }
    }
    
    
    private func setupMap() {
        guard let locations = location else { return }
        let lat = CLLocationDegrees(locations.latitude!)
        let long = CLLocationDegrees(locations.longitude!)
        let coordinate = CLLocationCoordinate2D(latitude: lat, longitude: long)
        let annotation = MKPointAnnotation()
        
        
       
        annotation.coordinate = coordinate
        let firstname = udacityAPIMethods.infoOfStudent.firstName
        let lastname = udacityAPIMethods.infoOfStudent.lastName
        
        annotation.title = "\(firstname) \(lastname)"
        annotation.subtitle = locations.mapString
        mapview.addAnnotation(annotation)
        let region = MKCoordinateRegion(center: coordinate, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
        mapview.setRegion(region, animated: true)
        
        
        
    }
    func showAlertError(_ errorString: String?) {
        if let errorString = errorString {
            self.displayAlert(title: "error", message: errorString)
        }
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        let useId = "pin"
        var pin = mapView.dequeueReusableAnnotationView(withIdentifier: useId) as? MKPinAnnotationView
        
        if pin == nil {
            pin = MKPinAnnotationView(annotation: annotation, reuseIdentifier: useId)
            pin!.canShowCallout = true
            pin!.pinTintColor = .red
            pin!.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
        }
        else {
            pin!.annotation = annotation
        }
        
        return pin
    }
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        if control == view.rightCalloutAccessoryView {
            let app = UIApplication.shared
            if let toOpen = view.annotation?.subtitle!,
                let url = URL(string: toOpen), app.canOpenURL(url) {
                app.open(url, options: [:], completionHandler: nil)
            }
        }
    }


}
