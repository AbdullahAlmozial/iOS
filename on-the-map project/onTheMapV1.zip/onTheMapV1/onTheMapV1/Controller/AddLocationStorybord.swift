//
//  AddLocationStorybord.swift
//  onTheMapV1
//
//  Created by عبدالله محمد on 1/15/19.
//  Copyright © 2019 udacity. All rights reserved.
//

import UIKit
import CoreLocation

private var userInfoo = infoOfStudents()

class AddLocationStorybord: UIViewController , UITextFieldDelegate  {
    
    @IBOutlet weak var locationTextField: UITextField!
    @IBOutlet weak var linkTextField: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()
        locationTextField.delegate = self
        linkTextField.delegate = self
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        subscribeToNotificationsObserver()
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        unsubscribeFromNotificationsObserver()
    }
    // for after click [Done] hide keyboard
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }

    @IBAction func findLocationAction(_ sender: Any) {
        
        if let studentlocation = locationTextField.text,
            let studentmediaLink = linkTextField.text,
            studentlocation != "", studentmediaLink != "" {
            let studentLocation = StudentLocation(mapString: studentlocation, mediaURL: studentmediaLink)
            geocodeCoordinates(studentLocation)
            
        }
            else {
                self.displayAlert(title: "forgot to enter", message: "Check the entered data")
                return
        }
    }
    
    @IBAction func cancel(_ sender: Any) {
          self.dismiss(animated: true, completion: nil)
    }
    
    private func geocodeCoordinates(_ studentLocation: StudentLocation) {
        
        let geocode = self.startAnActivityIndicator()
    CLGeocoder().geocodeAddressString(studentLocation.mapString!)
        { (placeMarks, err) in
            geocode.stopAnimating()
            guard let firstLocation = placeMarks?.first?.location else {
                self.displayAlert(title: "error", message: "problem with location")
                return }
            var location = studentLocation
            location.latitude = firstLocation.coordinate.latitude
            location.longitude = firstLocation.coordinate.longitude
            self.performSegue(withIdentifier: "addSegue", sender: location)
            
        }    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "addSegue", let vc = segue.destination as? sendLocationstorybord {
            vc.location = (sender as! StudentLocation)
        }
    }
    func subscribeToNotificationsObserver() {
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    func unsubscribeFromNotificationsObserver() {
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc func keyboardWillShow(_ notification: Notification) {
        guard let textField = UIResponder.Respond as? UITextField else { return }
        let keyboardHeight = getKeyboardHeight(notification)
        
        let kbMinY = (view.frame.height-keyboardHeight)
        var bottomCenter = textField.center
        bottomCenter.y += textField.frame.height/2
        let textFieldMaxY = textField.convert(bottomCenter, to: self.view).y
        if textFieldMaxY - kbMinY > 0 {
            
            view.frame.origin.y = -(textFieldMaxY - kbMinY)
        }
    }
    
    @objc func keyboardWillHide(_ notification: Notification) {
        view.frame.origin.y = 0
    }
    
    func getKeyboardHeight(_ notifition: Notification) -> CGFloat {
        let userInfo = notifition.userInfo
        let keyboardSize = userInfo![UIResponder.keyboardFrameEndUserInfoKey] as! NSValue
        return keyboardSize.cgRectValue.height
    }
}





extension UIViewController {
    func startAnActivityIndicator() -> UIActivityIndicatorView {
        let style = UIActivityIndicatorView(style: .gray)
        self.view.addSubview(style)
        self.view.bringSubviewToFront(style)
        style.center = self.view.center
        style.hidesWhenStopped = true
        style.startAnimating()
        return style
    }
    
}





