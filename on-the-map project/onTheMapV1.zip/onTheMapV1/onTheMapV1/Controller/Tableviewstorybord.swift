//
//  Tableviewstorybord.swift
//  onTheMapV1
//
//  Created by عبدالله محمد on 1/15/19.
//  Copyright © 2019 udacity. All rights reserved.
//

import UIKit
import SafariServices

class Tableviewstorybord: Shortcut {
    
    @IBOutlet weak var tableview: UITableView!
    

    override var locationsData: LocationsData? {
        didSet {
            guard let locationsData = locationsData else { return }
            locations = locationsData.studentLocations
        }
    }
    var locations: [StudentLocation] = [] {
        didSet {
            tableview.reloadData()
        }
    }


    @IBAction func logoutAction(_ sender: Any) {
        udacityAPIMethods.deldteSeesion() { (errorString) in
            UIUpdatesOnMain { //for DispatchQueue.main.async as TheMovieManager project
                guard errorString == nil else {
                    self.displayAlertError(errorString) // if any error as TheMovieManager
                    return
                }
                guard let vc = self.storyboard?.instantiateViewController(withIdentifier: "LogInViewController") as? LogInstorybord else {
                    return
                }
                self.dismiss(animated: true, completion: nil)
                self.navigationController?.pushViewController(vc, animated: true)
            } }
    }
    
    
    @IBAction func ReferchAction(_ sender: Any) {
        refrechStudentLocations()
    }
    
    @IBAction func addAction(_ sender: Any) {
        let navController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "AddLocation") as! UINavigationController
        present(navController, animated: true, completion: nil)
    }
    
    func displayAlertError(_ errorString: String?) {
        if let errorString = errorString {
            self.displayAlert(title: "Error", message: errorString) // change way of implemintion from show error on the lebel as TheMovieManager project to show on Alert
        }
    }
}


extension Tableviewstorybord: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return locations.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") as! TableViewCell
        
        cell.setdata(StudentData: locations[indexPath.row] as! StudentLocation)
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let dataArray = locations as! [StudentLocation]
        if let urladdress = dataArray[indexPath.row].mediaURL,
            let url = URL(string: urladdress){
            if url.absoluteString.contains("http://"){
                let urlsvc = SFSafariViewController(url: url)
                present(urlsvc, animated: true, completion: nil)
            }else {
                DispatchQueue.main.async {
             self.displayAlert(title: "error", message: "problem with website")
                }            }
            
        }
    }
    
    
    
}


