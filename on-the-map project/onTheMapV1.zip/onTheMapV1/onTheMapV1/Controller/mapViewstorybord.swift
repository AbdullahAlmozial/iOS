//
//  mapViewstorybord.swift
//  onTheMapV1
//
//  Created by عبدالله محمد on 1/15/19.
//  Copyright © 2019 udacity. All rights reserved.
//

import UIKit
import MapKit


class mapViewstorybord: Shortcut , MKMapViewDelegate {

    @IBOutlet weak var mapView: MKMapView!
    
    override var locationsData: LocationsData? {
        didSet {
            updatePins()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        
    }
    
    func updatePins() {
        guard let locations = locationsData?.studentLocations else { return }
        
        var annotations = [MKPointAnnotation]()
        
        for location in locations {
            
            // as PinSample but cahnge to codeable
            
            let latitude = location.latitude
            let longitude = location.longitude
            let latitud = CLLocationDegrees(latitude ?? 0)
            let longitud = CLLocationDegrees(longitude ?? 0)
            let coordinate = CLLocationCoordinate2D(latitude: latitud , longitude: longitud)
            
            let first = location.firstName
            let last = location.lastName
            let mediaURL = location.mediaURL
            
            let annotation = MKPointAnnotation()
            annotation.coordinate = coordinate
            annotation.title = "\(first ?? "") \(last ?? "")"
            annotation.subtitle = mediaURL
            
            annotations.append(annotation)
        }
        
        mapView.removeAnnotations(mapView.annotations)
        mapView.addAnnotations(annotations)
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        let reuseId = "pin"
        
        var pinView = mapView.dequeueReusableAnnotationView(withIdentifier: reuseId) as? MKPinAnnotationView
        
        if pinView == nil {
            pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
            pinView!.canShowCallout = true
            pinView!.pinTintColor = .red
            pinView!.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
        }
        else {
            pinView!.annotation = annotation
        }
        
        return pinView
    }

    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        if control == view.rightCalloutAccessoryView {
            let app = UIApplication.shared
            if let toOpen = view.annotation?.subtitle!,
                let url = URL(string: toOpen), app.canOpenURL(url) {
                app.open(url, options: [:], completionHandler: nil)
            }
        }
    }
    
    
    @IBAction func logoutAction(_ sender: Any) {
        
     
        udacityAPIMethods.deldteSeesion() { (errorString) in
            UIUpdatesOnMain { //for DispatchQueue.main.async as TheMovieManager project
                guard errorString == nil else {
                    self.showAlertError(errorString) // if any error as TheMovieManager
                    return
                }
                guard let vc = self.storyboard?.instantiateViewController(withIdentifier: "LogInViewController") as? LogInstorybord else {
                    return
                }
                 self.dismiss(animated: true, completion: nil)
                self.navigationController?.pushViewController(vc, animated: true)
            } }
    }
    
    
    
    @IBAction func refrechAction(_ sender: Any) {
   refrechStudentLocations()
    }
    
    @IBAction func addAction(_ sender: Any) {
        let navController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "AddLocation") as! UINavigationController
        present(navController, animated: true, completion: nil)
    }
    
    func showAlertError(_ errorString: String?) {
        if let errorString = errorString {
            self.displayAlert(title: "error", message: errorString)
        }
    }
    
    
    
}
