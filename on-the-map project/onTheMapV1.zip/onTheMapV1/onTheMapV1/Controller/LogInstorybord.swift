//
//  LogInstorybord.swift
//  onTheMapV1
//
//  Created by عبدالله محمد on 1/15/19.
//  Copyright © 2019 udacity. All rights reserved.
//

import UIKit

class LogInstorybord: UIViewController  , UITextFieldDelegate{
    
    
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        emailTextField.delegate = self
        passwordTextField.delegate = self
        

        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
       subscribeToNotificationsObserver()
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
         unsubscribeFromNotificationsObserver()
    }
    
    // for after click [Done] hide keyboard
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }

    
    
    @IBAction func loginAction(_ sender: Any) {
        
  
        udacityAPIMethods.postSession(username: emailTextField.text!, password: passwordTextField.text!) { (errorString) in
            UIUpdatesOnMain { //for DispatchQueue.main.async as TheMovieManager project
            guard errorString == nil else {
               self.showAlertError(errorString) // if any error as TheMovieManager
                return
            }
              self.doneLogin() // here it's suucceful  as TheMovieManager
                
                } }
        }
    
    @IBAction func signupAction(_ sender: Any) {
        udacityAPIMethods.signupurl()
    }
    
    private func doneLogin() {
         self.performSegue(withIdentifier: "Login", sender: nil) 
    }
    func showAlertError(_ errorString: String?) {
        if let errorString = errorString {
            self.displayAlert(title: "Error", message: errorString) // change way of implemintion from show error on the lebel as TheMovieManager project to show on Alert
        }
    }
    func subscribeToNotificationsObserver() {
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    func unsubscribeFromNotificationsObserver() {
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc func keyboardWillShow(_ notification: Notification) {
        guard let textField = UIResponder.Respond as? UITextField else { return }
        let keyboardHeight = getKeyboardHeight(notification)
        
        let kbMinY = (view.frame.height-keyboardHeight)
               var bottomCenter = textField.center
        bottomCenter.y += textField.frame.height/2
        let textFieldMaxY = textField.convert(bottomCenter, to: self.view).y
        if textFieldMaxY - kbMinY > 0 {
 
            view.frame.origin.y = -(textFieldMaxY - kbMinY)
        }
    }
    
    @objc func keyboardWillHide(_ notification: Notification) {
        view.frame.origin.y = 0
    }
    
    func getKeyboardHeight(_ notifition: Notification) -> CGFloat {
        let userInfo = notifition.userInfo
        let keyboardSize = userInfo![UIResponder.keyboardFrameEndUserInfoKey] as! NSValue
        return keyboardSize.cgRectValue.height
    }
}
    
    extension UIResponder {
        
        private static weak var Responder: UIResponder?
        
        static var Respond: UIResponder? {
            Responder = nil
            UIApplication.shared.sendAction(#selector(UIResponder.findFirstResponder(_:)), to: nil, from: nil, for: nil)
            
            return Responder
        }
        
        @objc func findFirstResponder(_ sender: Any) {
            UIResponder.Responder = self
        }
    }
    
    
  
  


