//
//  Shortcut.swift
//  onTheMapV1
//
//  Created by عبدالله محمد on 1/15/19.
//  Copyright © 2019 udacity. All rights reserved.
//

import UIKit

class Shortcut: UIViewController {

    var locationsData: LocationsData?
    
    override func viewDidLoad() {
        super.viewDidLoad()
refrechStudentLocations()
    }
    public func refrechStudentLocations() {
        udacityAPIMethods.ParserAPIMethods.getStudentLocations { (data) in
            UIUpdatesOnMain {
            guard let data = data else {
                self.displayAlert(title: "error", message: "No internet")
                return
            }
            guard data.studentLocations.count > 0 else {
                self.displayAlert(title: "error", message: "No pin")
                return
                }
            self.locationsData = data
            }}
    }
    
}
