//
//  RecordSoundViewController.swift
//  new pitch project
//
//  Created by عبدالله محمد on 11/6/18.
//  Copyright © 2018 udacity. All rights reserved.
//   RecordSoundViewController

import UIKit
import AVFoundation


class RecordSoundViewController: UIViewController ,AVAudioRecorderDelegate {
    
    var audioRecorder: AVAudioRecorder!

    @IBOutlet weak var recordingbutton: UIButton!
    
    @IBOutlet weak var stopingbutton: UIButton!
    
    @IBOutlet weak var recordinglabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       configureUI(isRecording: false)
        // Do any additional setup after loading the view, typically from a nib.
    }
    @IBAction func RecordAction(_ sender: Any) {
    configureUI(isRecording: true)
        
        
        let dirPath = NSSearchPathForDirectoriesInDomains(.documentDirectory,.userDomainMask, true)[0] as String
        let recordingName = "recordedVoice.wav"
        let pathArray = [dirPath, recordingName]
        let filePath = URL(string: pathArray.joined(separator: "/"))
        
        
        let session = AVAudioSession.sharedInstance()
        try! session.setCategory(.playAndRecord, mode: .default, options: .defaultToSpeaker)
        
        try! audioRecorder = AVAudioRecorder(url: filePath!, settings: [:])
          audioRecorder.delegate = self
        audioRecorder.isMeteringEnabled = true
        audioRecorder.prepareToRecord()
        audioRecorder.record()
    }
    
    @IBAction func stopAction(_ sender: Any) {
 configureUI(isRecording: false)
        
        audioRecorder.stop()
        let audoiSession = AVAudioSession.sharedInstance()
        try! audoiSession.setActive(false)
        
    }

    func audioRecorderDidFinishRecording(_ recorder: AVAudioRecorder, successfully flag: Bool) {
        if flag{
            performSegue(withIdentifier: "stopRecording", sender: audioRecorder.url)}
        else{
            
            print("RecordingIt'sNotSuccessful")
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == "stopRecording") {
            let palySoundVC = segue.destination as! PlaySoundsViewController
            let recordedAudioURL = sender as! URL
            palySoundVC.recordedAudioURL = recordedAudioURL
        }
    }
    
    func configureUI(isRecording: Bool) {
        if isRecording {
            recordinglabel.text="Recording Is Progress"
            stopingbutton.isEnabled = true
            recordinglabel.isEnabled = false
        } else {
            recordinglabel.text="Tap of record"
            stopingbutton.isEnabled = false
            recordinglabel.isEnabled = true
        }
    }
    
    
    

}

